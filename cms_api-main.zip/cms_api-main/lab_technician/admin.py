from django.contrib import admin
from .models import LabTest,LabTestReport
# Register your models here.
admin.site.register(LabTest)
admin.site.register(LabTestReport)