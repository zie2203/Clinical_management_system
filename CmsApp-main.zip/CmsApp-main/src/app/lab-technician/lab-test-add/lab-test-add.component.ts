import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-lab-test-add',
  templateUrl: './lab-test-add.component.html',
  styleUrls: ['./lab-test-add.component.scss']
})
export class LabTestAddComponent implements OnInit {

  constructor(public labservice:LabService ,public router:Router,private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(
    form:NgForm){
      console.log(form.value)
      this.addTests(form);
    }
    
    addTests(form:NgForm){
      console.log("Inserting.....")
      this.labservice.insertposts(form.value)
      .subscribe
      (result=>{
        console.log(result);
        this.router.navigate(['labtechnician/list'])
        this.resetForm(form);
        this.toastr.success("ADDED SUCCESSFULLY");
        this.router.navigate(['labtechnician/list'])
      })
    }
    resetForm(form:NgForm){
      if(form!=null){
        form.resetForm();
      }
    }

    goback():void{
      this.router.navigate(['labtechnician/home']);
    }
}
