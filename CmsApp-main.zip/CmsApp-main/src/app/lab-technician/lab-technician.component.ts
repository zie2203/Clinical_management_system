import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-technician',
  templateUrl: './lab-technician.component.html',
  styleUrls: ['./lab-technician.component.scss']
})
export class LabTechnicianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
