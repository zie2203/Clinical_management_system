import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LabTestPrescription } from 'src/app/shared/models/lab-test-prescription';
import { LabTestReport } from 'src/app/shared/models/lab-test-report';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-testreport-bill',
  templateUrl: './testreport-bill.component.html',
  styleUrls: ['./testreport-bill.component.scss']
})
export class TestreportBillComponent implements OnInit {

  doctorName: string = '';
  patientName: string = '';
  testName: string = '';
  price: number = 0;

  constructor(public labTechnicianService: LabService,private route: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.doctorName = params['doctorName'];
      this.patientName = params['patientName'];
      this.testName = params['testName'];
      this.price = params['price'];
      // Retrieve other data as needed for bill calculation or display
    });
  }

  calculateGST(): number {
    return this.price * 0.18; // Assuming the price is a decimal number
  }

  // Function to calculate the total bill amount (including GST) as a number
  calculateTotal(): number {
    const gst = this.calculateGST();
    const total = parseFloat(this.price.toString()) + parseFloat(gst.toString());
    return total;
  }
  goback():void{
    this.router.navigate(['labtechnician/finished_reports']);
  }
}
