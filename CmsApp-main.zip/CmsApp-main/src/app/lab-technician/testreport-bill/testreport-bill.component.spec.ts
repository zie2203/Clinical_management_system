import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestreportBillComponent } from './testreport-bill.component';

describe('TestreportBillComponent', () => {
  let component: TestreportBillComponent;
  let fixture: ComponentFixture<TestreportBillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestreportBillComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestreportBillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
