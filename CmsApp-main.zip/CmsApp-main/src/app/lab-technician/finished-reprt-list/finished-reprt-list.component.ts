import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LabTestReport } from 'src/app/shared/models/lab-test-report';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-finished-reprt-list',
  templateUrl: './finished-reprt-list.component.html',
  styleUrls: ['./finished-reprt-list.component.scss']
})
export class FinishedReprtListComponent implements OnInit {
  searchTerm:string='';
  p: number = 1;
  constructor(public labservice: LabService,private router:Router) { }

  ngOnInit(): void {
    this.labservice.finishedReportList();
  }
  redirectToPrintBill(prescription: LabTestReport) {
    const dataToSend = {
      doctorName: `${prescription.appointment.doctor.staff.first_name} ${prescription.appointment.doctor.staff.last_name}`,
      patientName: `${prescription.patient.first_name} ${prescription.patient.last_name}`,
      testName: prescription.test_type.test_name,
      price: prescription.test_type.price,
      // Add other necessary data for bill calculation or display
    };

    // Redirect to the Print Bill page and pass data through queryParams
    this.router.navigate(['labtechnician/print-bill'], { queryParams: dataToSend });
  }
  goback():void{
    this.router.navigate(['labtechnician/home']);
  }

}
