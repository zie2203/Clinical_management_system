import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinishedReprtListComponent } from './finished-reprt-list.component';

describe('FinishedReprtListComponent', () => {
  let component: FinishedReprtListComponent;
  let fixture: ComponentFixture<FinishedReprtListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinishedReprtListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FinishedReprtListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
