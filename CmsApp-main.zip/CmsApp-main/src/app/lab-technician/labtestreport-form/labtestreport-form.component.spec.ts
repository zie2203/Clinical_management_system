import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LabtestreportFormComponent } from './labtestreport-form.component';

describe('LabtestreportFormComponent', () => {
  let component: LabtestreportFormComponent;
  let fixture: ComponentFixture<LabtestreportFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LabtestreportFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LabtestreportFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
