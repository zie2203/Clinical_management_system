import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LabTestReport } from 'src/app/shared/models/lab-test-report';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-labtestreport-form',
  templateUrl: './labtestreport-form.component.html',
  styleUrls: ['./labtestreport-form.component.scss']
})
export class LabtestreportFormComponent implements OnInit {
  reportFormData: LabTestReport = new LabTestReport(); // Make sure you're using LabTestReport here

  constructor(public labservice:LabService,public router:Router,private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    console.log(form.value);
    this.editTest(form)
  }
  editTest(form:NgForm){
    console.log("editing...")
    this.labservice.labReportForm(form.value).subscribe((result=>{
      console.log(result);
      this.toastr.success("Submitted successfully");
      this.router.navigate(['/labtechnician/prescrib_list'])
    }))
  }
  goback():void{
    this.router.navigate(['labtechnician/prescrib_list']);
  }
}
