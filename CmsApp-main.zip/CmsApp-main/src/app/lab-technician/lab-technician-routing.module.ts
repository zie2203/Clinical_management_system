import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LabTestListComponent } from './lab-test-list/lab-test-list.component';
import { LabTestEditComponent } from './lab-test-edit/lab-test-edit.component';
import { HomedashboardComponent } from './homedashboard/homedashboard.component';
import { LabTestAddComponent } from './lab-test-add/lab-test-add.component';
import { LabtestreportListComponent } from './labtestreport-list/labtestreport-list.component';
import { LabtestreportFormComponent } from './labtestreport-form/labtestreport-form.component';
import { TestreportBillComponent } from './testreport-bill/testreport-bill.component';
import { FinishedReprtListComponent } from './finished-reprt-list/finished-reprt-list.component';

const routes: Routes = [
  {path:'list',component:LabTestListComponent},
  {path:'prescrib_list',component:LabtestreportListComponent},
  {path:'edit',component:LabTestEditComponent},
  {path:'add',component:LabTestAddComponent},
  {path:'home',component:HomedashboardComponent},
  {path:'edit/:id', component: LabTestEditComponent},
  {path:'report_edit/:id', component: LabtestreportFormComponent},
  {path:'report_edit', component: LabtestreportFormComponent},
  {path:'print-bill', component: TestreportBillComponent},
  {path:'finished_reports', component: FinishedReprtListComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LabTechnicianRoutingModule { }
