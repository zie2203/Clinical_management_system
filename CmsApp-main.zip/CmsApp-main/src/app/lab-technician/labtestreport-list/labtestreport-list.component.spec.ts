import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LabtestreportListComponent } from './labtestreport-list.component';

describe('LabtestreportListComponent', () => {
  let component: LabtestreportListComponent;
  let fixture: ComponentFixture<LabtestreportListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LabtestreportListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LabtestreportListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
