import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LabTestPrescription } from 'src/app/shared/models/lab-test-prescription';
import { LabTestReport } from 'src/app/shared/models/lab-test-report';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-labtestreport-list',
  templateUrl: './labtestreport-list.component.html',
  styleUrls: ['./labtestreport-list.component.scss']
})
export class LabtestreportListComponent implements OnInit {
  labTestReports: LabTestReport[] = []; // Populate this array with your LabTestReports data
  filteredReports: LabTestReport[] = [];
  searchTerm: string = '';
  constructor(public labservice: LabService,private router:Router) {}

  ngOnInit(): void {
    this.labservice.labPrescriptionList();
  }
  updateTestReport(prescription:LabTestReport){
    console.log(prescription);
    this.populatePostsData(prescription);
    this.router.navigate(['labtechnician/report_edit',prescription.id])
  }
  populatePostsData(prescription:LabTestReport) {
    this.labservice.reportFormData = Object.assign({},prescription)
  }

  goback():void{
    this.router.navigate(['labtechnician/home']);
  }
}