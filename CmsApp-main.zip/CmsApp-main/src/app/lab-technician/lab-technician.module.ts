import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LabTechnicianRoutingModule } from './lab-technician-routing.module';
import { LabTechnicianComponent } from './lab-technician.component';
import { LabTestListComponent } from './lab-test-list/lab-test-list.component';
import { LabTestAddComponent } from './lab-test-add/lab-test-add.component';
import { LabTestEditComponent } from './lab-test-edit/lab-test-edit.component';
import { HomedashboardComponent } from './homedashboard/homedashboard.component';
import { LabtestreportListComponent } from './labtestreport-list/labtestreport-list.component';
import { LabtestreportFormComponent } from './labtestreport-form/labtestreport-form.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { TestreportBillComponent } from './testreport-bill/testreport-bill.component';
import { FinishedReprtListComponent } from './finished-reprt-list/finished-reprt-list.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';


@NgModule({
  declarations: [
    LabTechnicianComponent,
    LabTestListComponent,
    LabTestAddComponent,
    LabTestEditComponent,
    HomedashboardComponent,
    LabtestreportListComponent,
    LabtestreportFormComponent,
    TestreportBillComponent,
    FinishedReprtListComponent
  ],
  imports: [
    CommonModule,
    LabTechnicianRoutingModule,
    FormsModule,
    SharedModule,
    NgxPaginationModule,
    Ng2SearchPipeModule
  ]
})
export class LabTechnicianModule { }
