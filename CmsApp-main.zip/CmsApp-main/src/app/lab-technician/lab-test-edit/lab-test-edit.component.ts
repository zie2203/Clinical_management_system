import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-lab-test-edit',
  templateUrl: './lab-test-edit.component.html',
  styleUrls: ['./lab-test-edit.component.scss']
})
export class LabTestEditComponent implements OnInit {

  constructor(public labservice:LabService,public router:Router,private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    console.log(form.value);
    this.editTest(form)
  }
  editTest(form:NgForm){
    console.log("editing...")
    this.labservice.updateTest(form.value).subscribe((result=>{
      console.log(result);
      this.toastr.success("edited successfully");
      this.router.navigate(['/labtechnician/list'])
    }))
  }

  goback():void{
    this.router.navigate(['labtechnician/list']);
  }

}
