import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LabTest } from 'src/app/shared/models/lab-test';
import { LabTestReport } from 'src/app/shared/models/lab-test-report';
import { LabService } from 'src/app/shared/services/lab.service';

@Component({
  selector: 'app-lab-test-list',
  templateUrl: './lab-test-list.component.html',
  styleUrls: ['./lab-test-list.component.scss']
})
export class LabTestListComponent implements OnInit {
  labTestReports: LabTestReport[] = []; // Populate this array with your LabTestReports data
  filteredReports: LabTestReport[] = [];
  searchTerm: string = '';
  p: number = 1;
  constructor(public labservice : LabService,public router:Router,private toastr:ToastrService) { }

  ngOnInit(): void {
    this.labservice.bindListPosts();
  }

  updateTest(p:LabTest){
    console.log(p);
    this.populatePostsData(p);
    this.router.navigate(['labtechnician/edit',p.id])
  }
  populatePostsData(p:LabTest) {
    this.labservice.formpostdata = Object.assign({},p)
  }
  deleteTest(_id:number){
    if (confirm("Are you sure to delete this?")){
      this.labservice.deleteTest(_id).subscribe((response)=>{
        console.log(response);
        this.toastr.success('Deleted successfully')
        this.labservice.bindListPosts();
      },(error)=>{
        console.log(error);
      })
    }
  }

  goback():void{
    this.router.navigate(['labtechnician/home']);
  }


}
