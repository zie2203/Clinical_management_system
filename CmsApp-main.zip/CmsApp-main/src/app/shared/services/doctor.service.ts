import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Appointment } from '../models/appointment';
import { PatientHealth } from '../models/patient-health';
import { Observable } from 'rxjs';
import { Medicine } from '../models/medicine';
import { MedicinePrescription } from '../models/medicine-prescription';
import { LabTest } from '../models/lab-test';
import { LabTestReport } from '../models/lab-test-report';
import { LabTestPrescription } from '../models/lab-test-prescription';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  appointments: Appointment[] = [];
  appointment: Appointment = new Appointment();
  medicines: Medicine[] = [];
  medicinePrescriptions: MedicinePrescription[] = [];
  labTests: LabTest[] = [];
  labTestReports: LabTestReport[] = [];
  patientHealths: PatientHealth[] = [];

  constructor(private httpClient: HttpClient) { }


  getAppointments(doctorId: string): void {
    this.httpClient.get<Appointment[]>(environment.apiUrl + "/api/appointments/?doctor=" + doctorId)
      .subscribe({
        next: (response) => {
          this.appointments = response;
        }
      });
  }

  getAppointment(appointmentId: string): void {
    this.httpClient.get<Appointment>(environment.apiUrl + "/api/appointment/" + appointmentId)
      .subscribe({
        next: (response) => {
          this.appointment = response;
        }
      });
  }

  getAge(date: Date): number {
    const today = new Date().getFullYear();
    const dob = new Date(date).getFullYear();
    return today - dob;
  }

  createPatientHealth(patientHealth: PatientHealth): Observable<PatientHealth> {
    patientHealth.appointment = this.appointment.id;
    patientHealth.patient = this.appointment.patient.id;
    return this.httpClient.post<PatientHealth>(environment.apiUrl + "/api/doctor/patient-healths/", patientHealth);
  }

  getMedicine(): void {
    this.httpClient.get<Medicine[]>(environment.apiUrl + "/api/pharmacist/medicince-list/")
      .subscribe({
        next: (response) => {
          this.medicines = response;
        }
      });
  }

  getMedicinePrescription(): void {
    this.httpClient.get<MedicinePrescription[]>(environment.apiUrl + "/api/doctor/medicine-prescriptions/?appointment=" + this.appointment.id)
      .subscribe({
        next: (response) => {
          console.log(response);
          this.medicinePrescriptions = response;
        }
      });
  }

  createMedicinePrescription(prescription: MedicinePrescription): Observable<MedicinePrescription> {
    prescription.appointment = this.appointment;
    prescription.patient = this.appointment.patient;
    for (let medicine of this.medicines) {
      if (typeof prescription.medicine === "string" && medicine.id.toString() === prescription.medicine) {
        prescription.medicine = medicine;
      } else if (medicine.id === prescription.medicine.id) {
        prescription.medicine = medicine;
      }
    }
    prescription.no_of_days = prescription.no_of_days;

    return this.httpClient.post<MedicinePrescription>(environment.apiUrl + "/api/doctor/medicine-prescriptions/", prescription);
  }

  getLabTest(): void {
    this.httpClient.get<LabTest[]>(environment.apiUrl + "/list_test")
      .subscribe({
        next: (response) => {
          this.labTests = response;
        }
      });
  }

  getLabTestReports(): void {
    this.httpClient.get<LabTestReport[]>(environment.apiUrl + "/list_testreport/?patient=" + this.appointment.patient.id)
      .subscribe({
        next: (response) => {
          this.labTestReports = response;
        }
      });
  }

  createLabTest(prescription: LabTestReport): Observable<LabTestReport> {
    prescription.appointment = this.appointment;
    prescription.patient = this.appointment.patient;
    for (let test of this.labTests) {
      if (typeof prescription.test_type === "string" && test.id.toString() === prescription.test_type) {
        prescription.test_type = test;
      } else if (test.id === prescription.test_type.id) {
        prescription.test_type = test;
      }
    }

    return this.httpClient.post<LabTestReport>(environment.apiUrl + "/list_testreport/", prescription);
  }

  getPatientHealths(): void {
    this.httpClient.get<PatientHealth[]>(environment.apiUrl + "/api/doctor/patient-healths/?patient=" + this.appointment.patient.id)
      .subscribe({
        next: (response) => {
          this.patientHealths = response;
        }
      });
  }

  updateAppointment(appointment: Appointment): Observable<Appointment>{
    return this.httpClient.patch<Appointment>(environment.apiUrl + "/api/appointments/edit/" + appointment.id, appointment);
  }
}
