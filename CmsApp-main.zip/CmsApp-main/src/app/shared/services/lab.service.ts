import { Injectable } from '@angular/core';
import { LabTest } from '../models/lab-test';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { LabTestPrescription } from '../models/lab-test-prescription';
import { LabTestReport } from '../models/lab-test-report';

@Injectable({
  providedIn: 'root'
})
export class LabService {

  lab : LabTest[] =[]
  formpostdata: LabTest = new LabTest();


  labTestReport : LabTestReport[] = []
  reportFormData: LabTestReport = new LabTestReport();


  constructor(private httpClient:HttpClient){}

  bindListPosts():void{
    this.httpClient.get<LabTest[]>(environment.apiUrl+ "/list_test").subscribe(response=>this.lab = response)
  }

  insertposts(lab:LabTest):Observable<any>{
    return this.httpClient.post(environment.apiUrl+"/list_test",lab)
  }

  updateTest(lab:LabTest):Observable<any>{
    console.log("in updating..");
    return this.httpClient.put(environment.apiUrl+"/test_details/"+lab.id,lab)
  }

  deleteTest(id:number){
    return this.httpClient.delete(environment.apiUrl+"/test_details/"+id)
  }

  // listTestReport(): Observable<LabTestPrescription[]> {
  //   return this.httpClient.get<LabTestPrescription[]>(environment.apiUrl + '/api/doctor/lab-test-prescriptions/');
  // }
  
  labPrescriptionList():void{
    this.httpClient.get<LabTestReport[]>(environment.apiUrl+ "/list_testreport/").subscribe(response=>this.labTestReport = response)
  }

  finishedReportList():void{
    this.httpClient.get<LabTestReport[]>(environment.apiUrl+ "/list_testreport/").subscribe(response=>this.labTestReport = response)
  }


  labReportForm(lab:LabTestReport):Observable<any>{
    console.log("in updating..");
    return this.httpClient.patch(environment.apiUrl+"/testreport_details/"+lab.id,lab)
  }

  viewReport(id: number): Observable<LabTestReport> {
    const url = `${environment.apiUrl}/testreport_details/${id}`;
    return this.httpClient.get<LabTestReport>(url);

  }
}