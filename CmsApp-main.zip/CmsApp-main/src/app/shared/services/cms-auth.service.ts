import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Login } from '../models/login';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class CmsAuthService {

  constructor(private httpClient: HttpClient) { }

  login(user: User): Observable<Login> {
    return this.httpClient.post<Login>(environment.apiUrl + "/api/cms_auth/login", user);
  }

  alreadyLogged(): string | null {
    return localStorage.getItem("STAFFROLE");
  }

  setStorage(login: Login): void {
    localStorage.setItem("USERNAME", login.username);
    localStorage.setItem("STAFFID", login.staff.id.toString());
    localStorage.setItem("STAFFROLE", login.staff.role.name);
    localStorage.setItem("TOKEN", login.token);
  }

  clearStorage(): void {
    localStorage.clear();
    sessionStorage.clear();
  }

  getAuthorizationToken(): string {
    return localStorage.getItem("TOKEN") as string;
  }

}
