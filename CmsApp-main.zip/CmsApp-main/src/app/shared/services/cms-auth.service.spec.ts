import { TestBed } from '@angular/core/testing';

import { CmsAuthService } from './cms-auth.service';

describe('CmsAuthService', () => {
  let service: CmsAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CmsAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
