import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Staff } from '../models/staff';
import { environment } from 'src/environments/environment';
import { Role } from '../models/role';
import { Designation } from '../models/designation';
import { Observable } from 'rxjs';
import { User } from '../models/user';
import { Doctor } from '../models/doctor';
import { Specialization } from '../models/specialization';
import { BloodGroup } from '../models/blood-group';

@Injectable({
  providedIn: 'root'
})
export class CmsAdminService {
  staffs: Staff[] = [];
  roles: Role[] = [];
  designations: Designation[] = [];
  doctors: Doctor[] = [];
  users: User[] = [];
  specializations: Specialization[] = [];
  bloodgroup: BloodGroup[] = [];
  formEditStaff: Staff = new Staff();
  formEditDoctor: Doctor = new Doctor();
  constructor(private httpClient: HttpClient) { }

  getStaffs() {
    this.httpClient.get<Staff[]>(environment.apiUrl + "/api/cms_admin/staffs")
      .subscribe({
        next: (response) => {
          this.staffs = response;
        }
      });
  }

  getRoles() {
    this.httpClient.get<Role[]>(environment.apiUrl + "/api/cms_admin/roles")
      .subscribe({
        next: (response) => {
          this.roles = response;
        }
      });
  }

  getDesignations() {
    this.httpClient.get<Designation[]>(environment.apiUrl + "/api/cms_admin/designations")
      .subscribe({
        next: (response) => {
          this.designations = response;
        }
      });
  }

  getUsers() {
    this.httpClient.get<User[]>(environment.apiUrl + "/api/cms_admin/users")
      .subscribe({
        next: (response) => {
          this.users = response;
        }
      });
  }

  getDoctors() {
    this.httpClient.get<Doctor[]>(environment.apiUrl + "/api/cms_admin/doctors")
      .subscribe({
        next: (response) => {
          this.doctors = response;
        }
      });
  }

  getSpecializations() {
    this.httpClient.get<Specialization[]>(environment.apiUrl + "/api/cms_admin/specializations")
      .subscribe({
        next: (response) => {
          this.specializations = response;
        }
      });
  }

  getBloodgroup() {
    this.httpClient.get<BloodGroup[]>(environment.apiUrl + "/api/cms_admin/roles")
      .subscribe({
        next: (response) => {
          this.bloodgroup = response;
        }
      });
  }





  createStaff(staff: Staff): Observable<Staff> {
    let postDesignation: Designation[] = [];
    for (let formDesignation of staff.designation) {
      for (let designation of this.designations) {
        if (typeof formDesignation === "string" && formDesignation === designation.id.toString()) {
          postDesignation.push(designation);
        } else if (formDesignation.id === designation.id) {
          postDesignation.push(designation);
        }
      }
    }
    staff.designation = postDesignation;

    for (let role of this.roles) {
      if (typeof staff.role === "string" && role.id.toString() === staff.role) {
        staff.role = role;
      } else if (role.id === staff.role.id) {
        staff.role = role;
      }
    }

    for (let user of this.users) {
      if (typeof staff.user === "string" && user.id.toString() === staff.user) {
        staff.user = user;
      } else if (user.id === staff.user.id) {
        staff.user = user;
      }
    }

    return this.httpClient.post<Staff>(environment.apiUrl + "/api/cms_admin/staffs", staff);
  }

  editStaff(staff: Staff): Observable<Staff> {
    let postDesignation: Designation[] = [];
    for (let formDesignation of staff.designation) {
      for (let designation of this.designations) {
        if (typeof formDesignation === "string" && formDesignation === designation.id.toString()) {
          postDesignation.push(designation);
        } else if (formDesignation.id === designation.id) {
          postDesignation.push(designation);
        }
      }
    }
    staff.designation = postDesignation;

    return this.httpClient.patch<Staff>(environment.apiUrl + "/api/cms_admin/staff/" + this.formEditStaff.id, staff);
  }

  createDoctor(doctor: any): Observable<Doctor> {
    const postDoctor = new Doctor();
    const postStaff = new Staff();

    let postDesignation: Designation[] = [];
    for (let formDesignation of doctor.designation) {
      for (let designation of this.designations) {
        if (typeof formDesignation === "string" && formDesignation === designation.id.toString()) {
          postDesignation.push(designation);
        } else if (formDesignation.id === designation.id) {
          postDesignation.push(designation);
        }
      }
    }
    postStaff.designation = postDesignation;

    for (let user of this.users) {
      if (typeof doctor.user === "string" && user.id.toString() === doctor.user) {
        postStaff.user = user;
      } else if (user.id === doctor.user.id) {
        postStaff.user = user;
      }
    }
    postStaff.first_name = doctor.first_name;
    postStaff.last_name = doctor.last_name;
    postStaff.dob = doctor.dob;
    postStaff.mobile_no = doctor.mobile_no;
    postStaff.address = doctor.address;
    postStaff.is_active = doctor.is_active;
    postStaff.is_enable = doctor.is_enable;
    const postRole = new Role();
    postRole.id = 2;
    postRole.name = "Doctor";
    postStaff.role = postRole;

    let postSpecialization: Specialization[] = [];
    for (let formSpecialization of doctor.specialization) {
      for (let specialization of this.specializations) {
        if (typeof formSpecialization === "string" && formSpecialization === specialization.id.toString()) {
          postSpecialization.push(specialization);
        } else if (formSpecialization.id === specialization.id) {
          postSpecialization.push(specialization);
        }
      }
    }
    postDoctor.specialization = postSpecialization;
    postDoctor.staff = postStaff;
    postDoctor.consultation_fee = doctor.consultation_fee;

    console.log(postDoctor);

    return this.httpClient.post<Doctor>(environment.apiUrl + "/api/cms_admin/doctors", postDoctor);
  }

  editDoctor(doctor: any): Observable<Doctor> {
    const postDoctor = new Doctor();
    const postStaff = new Staff();

    let postDesignation: Designation[] = [];
    for (let formDesignation of doctor.designation) {
      for (let designation of this.designations) {
        if (typeof formDesignation === "string" && formDesignation === designation.id.toString()) {
          postDesignation.push(designation);
        } else if (formDesignation.id === designation.id) {
          postDesignation.push(designation);
        }
      }
    }
    postStaff.designation = postDesignation;

    postStaff.first_name = doctor.first_name;
    postStaff.last_name = doctor.last_name;
    postStaff.dob = doctor.dob;
    postStaff.mobile_no = doctor.mobile_no;
    postStaff.address = doctor.address;
    postStaff.is_active = doctor.is_active;
    postStaff.is_enable = doctor.is_enable;
    postStaff.role = this.formEditDoctor.staff.role;

    let postSpecialization: Specialization[] = [];
    for (let formSpecialization of doctor.specialization) {
      for (let specialization of this.specializations) {
        if (typeof formSpecialization === "string" && formSpecialization === specialization.id.toString()) {
          postSpecialization.push(specialization);
        } else if (formSpecialization.id === specialization.id) {
          postSpecialization.push(specialization);
        }
      }
    }
    postDoctor.specialization = postSpecialization;
    postDoctor.staff = postStaff;
    postDoctor.consultation_fee = doctor.consultation_fee;

    console.log(postDoctor);

    return this.httpClient.patch<Doctor>(environment.apiUrl + "/api/cms_admin/doctor/" + this.formEditDoctor.id, postDoctor);
  }
}
