import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Medicine } from '../models/medicine';
import { MedicineState } from '../models/medicine-state';
import { Observable } from 'rxjs';
import { MedicinePrescription } from '../models/medicine-prescription';

@Injectable({
  providedIn: 'root'
})
export class PharmacistService {

  medicince:Medicine[]=[];
  mediStates: MedicineState[] = [];
  medicinePrescriptions: MedicinePrescription[] = [];
  
  FormPostsData:Medicine=new Medicine();

  constructor(private httpClient:HttpClient) { }
  
bindListPosts():void{
  this.httpClient.get<Medicine[]>(environment.apiUrl+"/api/pharmacist/medicince-list/").subscribe(response=>this.medicince=response);
}

getMedistate(){
  this.httpClient.get<MedicineState[]>(environment.apiUrl+"/api/pharmacist/medicine-states/")
  .subscribe({
    next: (response) =>{
      this.mediStates = response;
    }
  });
}

// insert record method
insertPosts(medicince:Medicine):Observable<any>{
  console.log(medicince);
  for (let state of this.mediStates) {
    if (typeof medicince.state === "string" && state.id.toString() === medicince.state) {
      medicince.state = state;
    } else if (state.id === medicince.state.id) {
      medicince.state = state;
    }
  }
  return this.httpClient.post(environment.apiUrl+ "/api/pharmacist/medicince-list/",medicince)
}

updateMedicince(medicince:Medicine):Observable<any>{
  console.log("in update");
  for (let state of this.mediStates) {
    if (typeof medicince.state === "string" && state.id.toString() === medicince.state) {
      medicince.state = state;
    } else if (state.id === medicince.state.id) {
      medicince.state = state;
    }
  }
  return this.httpClient.patch(environment.apiUrl + "/api/pharmacist/edit/"+ medicince.id,medicince)
  
}

getMedicinePrescription(appointmentId: string): void {
  this.httpClient.get<MedicinePrescription[]>(environment.apiUrl + "/api/doctor/medicine-prescriptions/?appointment=" + appointmentId)
    .subscribe({
      next: (response) => {
        this.medicinePrescriptions = response;
      }
    });
}


saveMedicineBill(): Observable<MedicinePrescription[]> {
  return this.httpClient.post<MedicinePrescription[]>(environment.apiUrl+ "/api/pharmacist/medicine-bill/",this.medicinePrescriptions);
}

}