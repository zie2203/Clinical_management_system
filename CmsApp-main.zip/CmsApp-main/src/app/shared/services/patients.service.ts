import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Patient } from '../models/patient';
import { Appointment } from '../models/appointment';
import { BloodGroup } from '../models/blood-group';
import { Specialization } from '../models/specialization';
import { Doctor } from '../models/doctor';
import { Staff } from '../models/staff';

@Injectable({
  providedIn: 'root'
})
export class PatientsService {
  staff : Staff[] =[];
  patients : Patient[] = [];
  appointment : Appointment[] = [];
  specialization : Specialization[] = [];
  bloodGroup : BloodGroup [] =[];
  doctor:Doctor[]=[];
  bill : Appointment= new Appointment();
  formPatientsData: Patient = new Patient();
  formAppointmentsData: Appointment = new Appointment();
  formBookAppointmentData: Appointment = new Appointment();
  constructor(private httpClient : HttpClient) { }
  //for list
  bindListPatients():void
  {
    this.httpClient.get<Patient[]>(environment.apiUrl+ "/api/cms_admin/patients").subscribe(response => this.patients = response);

  }
  insertPatients(patients:Patient):Observable<any>
  {
       console.log(patients)
      return this.httpClient.post(environment.apiUrl + "/api/cms_admin/patients", patients)
  }
  bindListAppointments():void
  {
    this.httpClient.get<Appointment[]>(environment.apiUrl+ "/api/appointments").subscribe(response => {
      this.appointment = response;
      console.log(this.appointment);
    });
  }
  updatePatient(patients:Patient) : Observable<any>
  {
    console.log("In Update");
    return this.httpClient.patch(environment.apiUrl + "/api/cms_admin/patient/" + patients.id, patients)

  }
  updateAppointments(appointment:Appointment) : Observable<any>
  {
    console.log("In Update");
    return this.httpClient.patch(environment.apiUrl + "/api/appointments/edit/" + appointment.id, appointment)

  }
  listDept () : void 
  {
    this.httpClient.get<[Specialization]>(environment.apiUrl+ "/api/cms_admin/specializations").subscribe(response => this.specialization = response);
  }
  listbloodgroup ():void
  {
     this.httpClient.get<[BloodGroup]>(environment.apiUrl+ "/api/cms_admin/blood-groups").subscribe(response => this.bloodGroup = response);
  }
  deletePatients(id : number) : Observable<any>
  {
    console.log("deleting..");
    return this.httpClient.delete(environment.apiUrl + "/api/cms_admin/patient/" + id);

  }
  bindListDoc():void{
    this.httpClient.get<Doctor[]>(environment.apiUrl+"/api/cms_admin/doctors")
    .subscribe(response=>this.doctor=response);
  }
  getDoctor(){
    this.httpClient.get<Doctor[]>(environment.apiUrl + "/api/cms_admin/doctors")
      .subscribe({
        next: (response) => {
          this.doctor = response;
        }
      });
  }
  
  getPatient(){
    this.httpClient.get<Patient[]>(environment.apiUrl + "/api/cms_admin/patients")
      .subscribe({
        next: (response) => {
          this.patients = response;
        }
      });
  }

  insertAppointment(appointment: Appointment): Observable<Appointment>{
      //   }
    // }
    return this.httpClient.post<Appointment>(environment.apiUrl + "/api/appointments/add", this.formBookAppointmentData);
  }
  getDoctorsBySpecialization(specializationIds: number[]) {
    // Join the specialization IDs into a comma-separated string
    const idsString = specializationIds.join(',');
  
    // Use the idsString in the URL or modify your endpoint accordingly
    return this.httpClient.get<Doctor[]>(environment.apiUrl +"/api/doctors_by_specialization/" + idsString);
}
getStaff():void
{
  this.httpClient.get<Staff[]>(environment.apiUrl+ "/api/cms_admin/staffs").subscribe(response => this.staff = response);

}

}
