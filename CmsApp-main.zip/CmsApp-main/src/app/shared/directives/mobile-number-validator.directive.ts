import { Directive } from '@angular/core';

@Directive({
  selector: '[appMobileNumberValidator]'
})
export class MobileNumberValidatorDirective {

  constructor() { }

}
