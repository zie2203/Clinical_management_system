import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validator } from '@angular/forms';

import { dateOfBirthValidator } from 'src/app/shared/cms-validators';


@Directive({
  selector: '[appDateOfBirthValidator]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: DateOfBirthValidatorDirective,
      multi: true,
    },
  ],
  standalone: true,
})
export class DateOfBirthValidatorDirective implements Validator {

  constructor() { }

  validate(control: AbstractControl): { [key: string]: any } | null {
    return dateOfBirthValidator(25, 60)(control);
  }

}
