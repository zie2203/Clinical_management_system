import { NameValidatorDirective } from './name-validator.directive';

describe('NameValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new NameValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
