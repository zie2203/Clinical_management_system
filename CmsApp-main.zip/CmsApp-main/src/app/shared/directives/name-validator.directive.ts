import { Directive } from '@angular/core';

@Directive({
  selector: '[appNameValidator]'
})
export class NameValidatorDirective {

  constructor() { }

}
