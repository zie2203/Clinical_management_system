import { MobileNumberValidatorDirective } from './mobile-number-validator.directive';

describe('MobileNumberValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MobileNumberValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
