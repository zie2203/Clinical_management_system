import { DateOfBirthValidatorDirective } from './date-of-birth-validator.directive';

describe('DateOfBirthValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new DateOfBirthValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
