import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function weightValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value < 1 || value > 1000)) {
      return { 'invalidWeight': true };
    }

    return null;
  };
}

export function temperatureValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value < 1 || value > 100)) {
      return { 'invalidTemperature': true };
    }

    return null;
  };
}

export function bloodPressureValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && !/^\d{1,3}\/\d{1,3}$/.test(value)) {
      return { 'invalidBloodPressure': true };
    }

    return null;
  };
}

export function sugarLevelValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value < 1 || value > 500)) {
      return { 'invalidSugarLevel': true };
    }

    return null;
  };
}

export function quantityValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value <= 0  || value > 1000)) {
      return { 'invalidQuantity': true };
    }

    return null;
  };
}

export function dosageValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value <= 0 || value > 1000)) {
      return { 'invalidDosage': true };
    }

    return null;
  };
}

export function numberOfDaysValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value <= 0 || value > 365)) {
      return { 'invalidNumberOfDays': true };
    }

    return null;
  };
}


export function nameValidator(minLength: number, maxLength: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    const validName = /^[a-zA-Z]+$/;

    if (!value || !validName.test(value) || value.trim().length < minLength || value.trim().length > maxLength) {
      return { 'invalidName': true };
    }

    return null;
  };
}

export function mobileNumberValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    const validMobileNumber = /^[0-9]{10}$/;

    if (!value || !validMobileNumber.test(value)) {
      return { 'invalidMobileNumber': true };
    }

    return null;
  };
}

export function dateOfBirthValidator(minAge: number, maxAge: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (!value) {
      return { 'invalidAge': true };
    }

    const dob = new Date(value);
    const currentDate = new Date();
    const age = currentDate.getFullYear() - dob.getFullYear();

    if (age <= minAge || age > maxAge) {
      return { 'invalidAge': true };
    }

    return null;
  };
}

export function consultationFeeValidator(minLength: number, maxLength: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && (isNaN(value) || value <= minLength || value > maxLength)) {
      return { 'invalidConsultationFee': true };
    }

    return null;
  };
}