import { Staff } from "./staff";

export class Login {
  username: string = "";
  staff: Staff = new Staff();
  token: string = "";
}
