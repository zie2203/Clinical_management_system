import { MedicinePrescription } from './medicine-prescription';

describe('MedicinePrescription', () => {
  it('should create an instance', () => {
    expect(new MedicinePrescription()).toBeTruthy();
  });
});
