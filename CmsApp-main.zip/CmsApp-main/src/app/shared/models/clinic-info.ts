export class ClinicInfo {
  id: number = 0;
  name: string = "";
  reg_id: string = "";
}
