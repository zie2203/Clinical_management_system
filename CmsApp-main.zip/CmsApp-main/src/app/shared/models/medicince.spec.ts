// import { Medicince } from './medicince';

// describe('Medicince', () => {
//   it('should create an instance', () => {
//     expect(new Medicince()).toBeTruthy();
//   });
// });
