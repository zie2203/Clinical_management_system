export class Designation {
  id: number = 0;
  name: string = "";
}
