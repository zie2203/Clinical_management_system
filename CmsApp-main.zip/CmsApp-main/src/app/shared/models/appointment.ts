import { Doctor } from "./doctor";
import { Patient } from "./patient"

export class Appointment {
  id: number = 0;
  patient: Patient = new Patient();
  doctor: Doctor = new Doctor();
  appointment_time: Date = new Date();
  is_done: boolean = false;
}
