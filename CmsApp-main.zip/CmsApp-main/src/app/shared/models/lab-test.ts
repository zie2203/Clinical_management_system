export class LabTest {
  id: number = 0;
  test_name: string = "";
  created_date: Date = new Date();
  price: number = 0;
  is_active: boolean = true;
  is_enable: boolean = true;
}
