import { Staff } from './staff';

describe('Staff', () => {
  it('should create an instance', () => {
    expect(new Staff()).toBeTruthy();
  });
});
