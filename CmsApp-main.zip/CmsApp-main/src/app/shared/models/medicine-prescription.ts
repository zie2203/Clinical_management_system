import { Appointment } from "./appointment";
import { Medicine } from "./medicine";
import { Patient } from "./patient";

export class MedicinePrescription {
  id: number = 0;
  medicine: Medicine = new Medicine();
  quantity: number = 0;
  dosage: number = 0;
  no_of_days: string = "";
  appointment: Appointment = new Appointment();
  patient: Patient = new Patient();
}