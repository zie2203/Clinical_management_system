export class BloodGroup {
  id: number = 0;
  name:string = "";
}
