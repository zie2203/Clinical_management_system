import { ClinicInfo } from './clinic-info';

describe('ClinicInfo', () => {
  it('should create an instance', () => {
    expect(new ClinicInfo()).toBeTruthy();
  });
});
