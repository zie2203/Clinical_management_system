import { Designation } from './designation';

describe('Designation', () => {
  it('should create an instance', () => {
    expect(new Designation()).toBeTruthy();
  });
});
