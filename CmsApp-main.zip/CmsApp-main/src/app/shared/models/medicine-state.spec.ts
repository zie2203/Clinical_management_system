import { MedicineState } from './medicine-state';

describe('MedicineState', () => {
  it('should create an instance', () => {
    expect(new MedicineState()).toBeTruthy();
  });
});
