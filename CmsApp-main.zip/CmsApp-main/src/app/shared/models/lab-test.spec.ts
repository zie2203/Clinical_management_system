import { LabTest } from './lab-test';

describe('LabTest', () => {
  it('should create an instance', () => {
    expect(new LabTest()).toBeTruthy();
  });
});
