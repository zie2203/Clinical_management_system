import { Appointment } from "./appointment"
import { LabTest } from "./lab-test";
import { Patient } from "./patient";

export class LabTestPrescription {
  id: number = 0;
  appointment: Appointment = new Appointment();
  patient: Patient = new Patient();
  lab_test: LabTest = new LabTest();
}
