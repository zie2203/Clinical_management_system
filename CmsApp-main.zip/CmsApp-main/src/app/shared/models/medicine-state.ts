export class MedicineState {
  id: number = 0;
  name: string = "";
}
