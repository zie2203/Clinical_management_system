import { PatientHealth } from './patient-health';

describe('PatientHealth', () => {
  it('should create an instance', () => {
    expect(new PatientHealth()).toBeTruthy();
  });
});
