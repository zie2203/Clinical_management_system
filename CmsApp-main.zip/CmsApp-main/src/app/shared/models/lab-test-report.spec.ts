import { LabTestReport } from './lab-test-report';

describe('LabTestReport', () => {
  it('should create an instance', () => {
    expect(new LabTestReport()).toBeTruthy();
  });
});
