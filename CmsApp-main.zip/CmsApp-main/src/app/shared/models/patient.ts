import { BloodGroup } from "./blood-group"


/*
export class Patient {
  id: number = 0;
  first_name: string = " ";
  last_name: string = " ";
  address: string = " ";
  is_active: boolean = true;
  is_enable: boolean = true;
  dob: Date = new Date();
  mobile_no: number = 0;
  bloodGroup: bloodGroup = new bloodGroup(); // Correct casing
  image: string | null = null;
}
 export class bloodGroup {
  id: number = 0;
  name:string = " ";
}*/
export class Patient {
  id: number = 0;
  first_name: string = " ";
  last_name: string = " ";
  address: string = " ";
  is_active: boolean = true;
  is_enable: boolean = true;
  dob: Date = new Date();
  mobile_no: number = 0;
  image: string | null = null;
  bloodGroup: {
    id: number;
    name: string;
  } = { id: 0, name: "" }; // Initialize bloodGroup without a constructor
}