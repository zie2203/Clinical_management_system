import { Designation } from "./designation";
import { Role } from "./role";
import { User } from "./user";

export class Staff {
  id: number = 0;
  user: User = new User();
  first_name: string = "";
  last_name: string = "";
  dob: Date = new Date();
  mobile_no: string = "";
  designation: Designation[] = [];
  role: Role = new Role();
  address: string = "";
  image: string | null = "";
  is_active: boolean = true;
  is_enable: boolean = true;
}
