import { MedicineState } from "./medicine-state";

export class Medicine {
  id: number = 0;
  medicince_name: string = "";
  genericName: string = "";
  companyName: string = "";
  quantity: number = 0;
  rate: number = 0;
  state: MedicineState = new MedicineState();
  expiration_date: Date = new Date();
  is_active: boolean = true;
  is_enable: boolean = true;
}
