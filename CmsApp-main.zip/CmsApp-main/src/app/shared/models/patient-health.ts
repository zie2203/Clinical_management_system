export class PatientHealth {
  id: number = 0;
  appointment: number = 0;
  patient: number = 0;
  weight: number = 0;
  blood_pressure: string = "";
  sugar_level: number = 0;
  temperature: number = 0;
  diagnosis: string = "";
  note: string = "";
}
