import { Appointment } from "./appointment";
import { LabTest } from "./lab-test";
import { Patient } from "./patient"

export class LabTestReport {
  id: number = 0;
  appointment: Appointment = new Appointment();
  patient: Patient = new Patient();
  test_type: LabTest = new LabTest();
  result: boolean = false;
  report: string = "";
}
