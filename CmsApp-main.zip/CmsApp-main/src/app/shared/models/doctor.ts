import { Specialization } from "./specialization";
import { Staff } from "./staff"

export class Doctor {
  id: number = 0;
  staff: Staff = new Staff();
  specialization: Specialization[] = [];
  consultation_fee: number = 0;
}
