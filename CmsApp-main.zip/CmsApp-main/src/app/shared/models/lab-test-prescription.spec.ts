import { LabTestPrescription } from './lab-test-prescription';

describe('LabTestPrescription', () => {
  it('should create an instance', () => {
    expect(new LabTestPrescription()).toBeTruthy();
  });
});
