import { BloodGroup } from './blood-group';

describe('BloodGroup', () => {
  it('should create an instance', () => {
    expect(new BloodGroup()).toBeTruthy();
  });
});
