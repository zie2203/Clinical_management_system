export class Role {
  id: number = 0;
  name: string = "";
}
