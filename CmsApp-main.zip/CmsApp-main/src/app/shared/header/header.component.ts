import { Component, OnInit } from '@angular/core';
import { CmsAuthService } from '../services/cms-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private authService: CmsAuthService, private router: Router) { }

  ngOnInit(): void {
  }

  logout(): void{
    if(confirm("Do you want to Logout?")){
      this.authService.clearStorage();
      this.router.navigate(["auth/login"]);
    }
  }


}
