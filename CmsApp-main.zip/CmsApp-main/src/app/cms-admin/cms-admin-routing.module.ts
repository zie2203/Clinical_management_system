import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StaffAddComponent } from './staff/staff-add/staff-add.component';
import { StaffEditComponent } from './staff/staff-edit/staff-edit.component';
import { DoctorAddComponent } from './doctor/doctor-add/doctor-add.component';
import { DoctorEditComponent } from './doctor/doctor-edit/doctor-edit.component';
import { DashboardComponent } from './dashboard/dashboard.component';
 
const routes: Routes = [
  {
    path: "",
    component: DashboardComponent,
  },
  {
    path: "staff/add",
    component: StaffAddComponent,
  },
  {
    path: "staff/edit",
    component: StaffEditComponent,
  },
  {
    path: "doctor/add",
    component: DoctorAddComponent,
  },
  {
    path: "doctor/edit",
    component: DoctorEditComponent,
  },

  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CmsAdminRoutingModule { }
