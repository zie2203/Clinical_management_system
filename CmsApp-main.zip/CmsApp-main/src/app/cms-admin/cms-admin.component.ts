import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-admin',
  templateUrl: './cms-admin.component.html',
  styleUrls: ['./cms-admin.component.scss']
})
export class CmsAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
