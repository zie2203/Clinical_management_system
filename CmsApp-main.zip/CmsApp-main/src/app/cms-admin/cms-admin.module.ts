import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmsAdminRoutingModule } from './cms-admin-routing.module';
import { CmsAdminComponent } from './cms-admin.component';
import { StaffAddComponent } from './staff/staff-add/staff-add.component';
import { StaffEditComponent } from './staff/staff-edit/staff-edit.component';
import { DoctorAddComponent } from './doctor/doctor-add/doctor-add.component';
import { DoctorEditComponent } from './doctor/doctor-edit/doctor-edit.component';
import { SharedModule } from '../shared/shared.module';
import { DoctorListComponent } from './doctor/doctor-list/doctor-list.component';
import { StaffListComponent } from './staff/staff-list/staff-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
 
import { DesignationComponent } from './designation/designation.component'; 

@NgModule({
  declarations: [
    CmsAdminComponent,
    StaffAddComponent,
    StaffEditComponent,
    DoctorAddComponent,
    DoctorEditComponent,
    DoctorListComponent,
    StaffListComponent,
    DashboardComponent,
    
    DesignationComponent,
     
    
  ],
  imports: [
    CommonModule,
    CmsAdminRoutingModule,
    ReactiveFormsModule,
    SharedModule,
    FormsModule,
  ]
})
export class CmsAdminModule { }
