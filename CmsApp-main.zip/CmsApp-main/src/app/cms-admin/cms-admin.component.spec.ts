import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmsAdminComponent } from './cms-admin.component';

describe('CmsAdminComponent', () => {
  let component: CmsAdminComponent;
  let fixture: ComponentFixture<CmsAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CmsAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmsAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
