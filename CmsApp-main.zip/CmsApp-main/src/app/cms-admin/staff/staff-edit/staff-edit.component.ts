import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { dateOfBirthValidator, mobileNumberValidator, nameValidator } from 'src/app/shared/cms-validators';
import { CmsAdminService } from 'src/app/shared/services/cms-admin.service';

@Component({
  selector: 'app-staff-edit',
  templateUrl: './staff-edit.component.html',
  styleUrls: ['./staff-edit.component.scss']
})
export class StaffEditComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private adminService: CmsAdminService, private toastr: ToastrService, private router:Router) {
    this.myForm = this.fb.group({
      first_name: ["", [Validators.required, nameValidator(3, 16)]],
      last_name: ["", [Validators.required, nameValidator(3, 16)]],
      dob: ["", [Validators.required, dateOfBirthValidator(25, 60)]],
      mobile_no: ["", [Validators.required, mobileNumberValidator()]],
      designation: "",
      address: ["", [Validators.required]],
      is_active: true,
      is_enable: true,
    });
  }

  ngOnInit(): void {
    this.adminService.getUsers();
    this.adminService.getDesignations();
    this.adminService.getRoles();
    const staff = this.adminService.formEditStaff;
    this.myForm.setValue({
      first_name: staff.first_name,
      last_name: staff.last_name,
      dob: staff.dob,
      mobile_no: staff.mobile_no,
      designation: staff.designation,
      address: staff.address,
      is_active: staff.is_active,
      is_enable: staff.is_enable,
    });
  }

  get service() {
    return this.adminService;
  }

  get first_name(){
    return this.myForm.get("first_name");
  }

  get last_name(){
    return this.myForm.get("last_name");
  }

  get dob(){
    return this.myForm.get("dob");
  }

  get mobile_no(){
    return this.myForm.get("mobile_no");
  }

  get designation(){
    return this.myForm.get("designation");
  }

  get address(){
    return this.myForm.get("address");
  }

  onSubmit(): void {
    console.log(this.myForm.value);
    if(this.myForm.valid){
      this.adminService.editStaff(this.myForm.value)
      .subscribe({
        next: (response) => {
          this.toastr.success("Added Successfully");
          this.router.navigate([''])
          this.myForm.reset();
        },
        error: (error) => {
          console.log(error);
          this.toastr.error("Invalid Details");
        }
      });
    }
  }
}
