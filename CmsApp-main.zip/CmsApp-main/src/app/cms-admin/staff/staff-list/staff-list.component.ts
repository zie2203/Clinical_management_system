import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Staff } from 'src/app/shared/models/staff';
import { CmsAdminService } from 'src/app/shared/services/cms-admin.service';

@Component({
  selector: 'app-staff-list',
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.scss']
})
export class StaffListComponent implements OnInit {


  constructor(public adminService: CmsAdminService, private router: Router) { }

  ngOnInit(): void {
    this.adminService.getStaffs();
  }

  addStaff() {
    this.router.navigate(["admin/staff/add"]);
  }

  editStaff(staff: Staff) {
    this.adminService.formEditStaff = staff;
    this.router.navigate(["admin/staff/edit"]);
  }

}
