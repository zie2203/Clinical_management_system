import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CmsAdminService } from 'src/app/shared/services/cms-admin.service';
import { dateOfBirthValidator, mobileNumberValidator, nameValidator } from 'src/app/shared/cms-validators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-staff-add',
  templateUrl: './staff-add.component.html',
  styleUrls: ['./staff-add.component.scss']
})
export class StaffAddComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private adminService: CmsAdminService, private toastr: ToastrService,private router:Router) {
    this.myForm = this.fb.group({
      first_name: ["", [Validators.required, nameValidator(3, 16)]],
      last_name: ["", [Validators.required, nameValidator(3, 16)]],
      dob: ["", [Validators.required, dateOfBirthValidator(25, 60)]],
      mobile_no: ["", [Validators.required, mobileNumberValidator()]],
      user: ["", [Validators.required]],
      designation: ["", [Validators.required]],
      role: ["", [Validators.required]],
      address: ["", [Validators.required]],
      is_active: true,
      is_enable: true,
    });
  }

  ngOnInit(): void {
    this.adminService.getUsers();
    this.adminService.getDesignations();
    this.adminService.getRoles();
  }

  get service() {
    return this.adminService;
  }

  get first_name(){
    return this.myForm.get("first_name");
  }

  get last_name(){
    return this.myForm.get("last_name");
  }

  get dob(){
    return this.myForm.get("dob");
  }

  get mobile_no(){
    return this.myForm.get("mobile_no");
  }

  get user(){
    return this.myForm.get("user");
  }

  get designation(){
    return this.myForm.get("designation");
  }

  get role(){
    return this.myForm.get("role");
  }

  get address(){
    return this.myForm.get("address");
  }


  onSubmit(): void {
    console.log(this.myForm.value);
    if(this.myForm.valid){
      this.adminService.createStaff(this.myForm.value)
        .subscribe({
          next: (response) => {
            this.toastr.success("Added Successfully");
            this.router.navigate([''])
            this.myForm.reset();
          },
          error: (error) => {
            console.log(error);
            this.toastr.error("Invalid Details");
          }
        });
    }
  }

}
