import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { nameValidator, dateOfBirthValidator, mobileNumberValidator, consultationFeeValidator } from 'src/app/shared/cms-validators';
import { CmsAdminService } from 'src/app/shared/services/cms-admin.service';

@Component({
  selector: 'app-doctor-edit',
  templateUrl: './doctor-edit.component.html',
  styleUrls: ['./doctor-edit.component.scss']
})
export class DoctorEditComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private adminService: CmsAdminService, private toastr: ToastrService, private router: Router) {
    this.myForm = this.fb.group({
      first_name: ["", [Validators.required, nameValidator(3, 16)]],
      last_name: ["", [Validators.required, nameValidator(3, 16)]],
      dob: ["", [Validators.required, dateOfBirthValidator(25, 60)]],
      mobile_no: ["", [Validators.required, mobileNumberValidator()]],
      designation: [],
      address: ["", [Validators.required]],
      specialization: [],
      consultation_fee: ["", [Validators.required, consultationFeeValidator(100, 50000)]],
      is_active: true,
      is_enable: true,
    });
  }

  ngOnInit(): void {
    this.adminService.getUsers();
    this.adminService.getDesignations();
    this.adminService.getRoles();
    this.adminService.getSpecializations();
    const doctor = this.adminService.formEditDoctor;
    this.myForm.setValue({
      first_name: doctor.staff.first_name,
      last_name: doctor.staff.last_name,
      dob: doctor.staff.dob,
      mobile_no: doctor.staff.mobile_no,
      designation: doctor.staff.designation,
      address: doctor.staff.address,
      specialization: doctor.specialization,
      consultation_fee: doctor.consultation_fee,
      is_active: doctor.staff.is_active,
      is_enable: doctor.staff.is_enable,
    });
  }

  get service(){
    return this.adminService;
  }

  get first_name(){
    return this.myForm.get("first_name");
  }

  get last_name(){
    return this.myForm.get("last_name");
  }

  get dob(){
    return this.myForm.get("dob");
  }

  get mobile_no(){
    return this.myForm.get("mobile_no");
  }
  
  get designation(){
    return this.myForm.get("designation");
  }

  get address(){
    return this.myForm.get("address");
  }

  get specialization(){
    return this.myForm.get("specialization");
  }

  get consultation_fee(){
    return this.myForm.get("consultation_fee");
  }

  onSubmit(){
    console.log(this.myForm.value);
    if(this.myForm.valid){
      this.adminService.editDoctor(this.myForm.value)
        .subscribe({
          next: (response) => {
            this.toastr.success("Added Successfully");
            this.router.navigate([''])
            this.myForm.reset();
            
          },
          error: (error) => {
            console.log(error);
            this.toastr.error("Invalid Details");
          }
        });
    }
  }

}
