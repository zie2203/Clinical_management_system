import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { nameValidator, dateOfBirthValidator, mobileNumberValidator, consultationFeeValidator } from 'src/app/shared/cms-validators';
import { CmsAdminService } from 'src/app/shared/services/cms-admin.service';

@Component({
  selector: 'app-doctor-add',
  templateUrl: './doctor-add.component.html',
  styleUrls: ['./doctor-add.component.scss']
})
export class DoctorAddComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private adminService: CmsAdminService, private toastr: ToastrService,private router:Router) {
    this.myForm = this.fb.group({
      first_name: ["", [Validators.required, nameValidator(3, 16)]],
      last_name: ["", [Validators.required, nameValidator(3, 16)]],
      dob: ["", [Validators.required, dateOfBirthValidator(25, 60)]],
      mobile_no: ["", [Validators.required, mobileNumberValidator()]],
      user: ["", [Validators.required]],
      designation: ["", [Validators.required]],
      address: ["", [Validators.required]],
      specialization: ["", [Validators.required]],
      consultation_fee: ["", [Validators.required, consultationFeeValidator(100, 50000)]],
      is_active: true,
      is_enable: true,
    });
  }

  ngOnInit(): void {
    this.adminService.getUsers();
    this.adminService.getDesignations();
    this.adminService.getRoles();
    this.adminService.getSpecializations();
  }

  get service(){
    return this.adminService;
  }

  get first_name(){
    return this.myForm.get("first_name");
  }

  get last_name(){
    return this.myForm.get("last_name");
  }

  get dob(){
    return this.myForm.get("dob");
  }

  get mobile_no(){
    return this.myForm.get("mobile_no");
  }

  get user(){
    return this.myForm.get("user");
  }

  get designation(){
    return this.myForm.get("designation");
  }

  get address(){
    return this.myForm.get("address");
  }

  get specialization(){
    return this.myForm.get("specialization");
  }

  get consultation_fee(){
    return this.myForm.get("consultation_fee");
  }


  onSubmit(): void {
    console.log(this.myForm.value);
    if(this.myForm.valid){
      this.adminService.createDoctor(this.myForm.value)
      .subscribe({
        next: (response) => {
          this.toastr.success("Added Successfully");
          this.router.navigate([''])
          this.myForm.reset();
        },
        error: (error) => {
          console.log(error);
          this.toastr.error("Invalid Details");
        }
      });
    }
  }

}
