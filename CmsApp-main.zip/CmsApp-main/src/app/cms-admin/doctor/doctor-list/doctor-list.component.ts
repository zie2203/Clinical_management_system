import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Doctor } from 'src/app/shared/models/doctor';
import { CmsAdminService } from 'src/app/shared/services/cms-admin.service';

@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.scss']
})
export class DoctorListComponent implements OnInit {

  constructor(public adminService: CmsAdminService, private router: Router) { }

  ngOnInit(): void {
    this.adminService.getDoctors();
  }

  addDoctor() {
    this.router.navigate(["admin/doctor/add"]);
  }

  editDoctor(doctor: Doctor) {
    this.adminService.formEditDoctor = doctor;
    this.router.navigate(["admin/doctor/edit"]);
  }

}
