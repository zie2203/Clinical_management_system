import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CmsAdminComponent } from './cms-admin/cms-admin.component';
import { ReceptionistComponent } from './receptionist/receptionist.component';
import { CmsAuthComponent } from './cms-auth/cms-auth.component';
import { DoctorComponent } from './doctor/doctor.component';
import { LabTechnicianComponent } from './lab-technician/lab-technician.component';
import { PharmacistComponent } from './pharmacist/pharmacist.component';
import { NotFoundComponent } from './shared/not-found/not-found.component';

const routes: Routes = [
  {
    path: "",
    redirectTo: "auth/login",
    pathMatch: 'full'
  },
  {
    path: "admin",
    component: CmsAdminComponent,
    loadChildren: () => import("./cms-admin/cms-admin.module").then(x => x.CmsAdminModule),
  },
  {
    path: "auth",
    component: CmsAuthComponent,
    loadChildren: () => import("./cms-auth/cms-auth.module").then(x => x.CmsAuthModule),
  },
  {
    path: "receptionist",
    component: ReceptionistComponent,
    loadChildren: () => import("./receptionist/receptionist.module").then(x => x.ReceptionistModule),
  },
  {
    path: "doctor",
    component: DoctorComponent,
    loadChildren: () => import("./doctor/doctor.module").then(x => x.DoctorModule),
  },
  {
    path: "labtechnician",
    component: LabTechnicianComponent,
    loadChildren: () => import("./lab-technician/lab-technician.module").then(x => x.LabTechnicianModule),
  },
  {
    path: "pharmacist",
    component: PharmacistComponent,
    loadChildren: () => import("./pharmacist/pharmacist.module").then(x => x.PharmacistModule),
  },
  {
    path: "**",
    component: NotFoundComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
