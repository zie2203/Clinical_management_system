import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DoctorService } from 'src/app/shared/services/doctor.service';

@Component({
  selector: 'app-patient-treatment-history',
  templateUrl: './patient-treatment-history.component.html',
  styleUrls: ['./patient-treatment-history.component.scss']
})
export class PatientTreatmentHistoryComponent implements OnInit {

  constructor(private doctorService: DoctorService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.getPatientHealths();
  }

  get service(): DoctorService{
    return this.doctorService;
  }

}
