import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientTreatmentHistoryComponent } from './patient-treatment-history.component';

describe('PatientTreatmentHistoryComponent', () => {
  let component: PatientTreatmentHistoryComponent;
  let fixture: ComponentFixture<PatientTreatmentHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientTreatmentHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientTreatmentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
