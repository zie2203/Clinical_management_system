import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DoctorRoutingModule } from './doctor-routing.module';
import { DoctorComponent } from './doctor.component';
import { PatientMedicineComponent } from './patient-medicine/patient-medicine.component';
import { PatientLabTestComponent } from './patient-lab-test/patient-lab-test.component';
import { PatientTreatmentHistoryComponent } from './patient-treatment-history/patient-treatment-history.component';
import { PatientDiagnosisComponent } from './patient-diagnosis/patient-diagnosis.component';
import { PatientRecordComponent } from './patient-record/patient-record.component';
import { PatientAppointmentsComponent } from './patient-appointments/patient-appointments.component';
import { DoctorDashboardComponent } from './doctor-dashboard/doctor-dashboard.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    DoctorComponent,
    PatientMedicineComponent,
    PatientLabTestComponent,
    PatientTreatmentHistoryComponent,
    PatientDiagnosisComponent,
    PatientRecordComponent,
    PatientAppointmentsComponent,
    DoctorDashboardComponent
  ],
  imports: [
    CommonModule,
    DoctorRoutingModule,
    ReactiveFormsModule,
    SharedModule,
  ]
})
export class DoctorModule { }
