import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Appointment } from 'src/app/shared/models/appointment';
import { DoctorService } from 'src/app/shared/services/doctor.service';

@Component({
  selector: 'app-patient-appointments',
  templateUrl: './patient-appointments.component.html',
  styleUrls: ['./patient-appointments.component.scss']
})
export class PatientAppointmentsComponent implements OnInit {

  constructor(private doctorService: DoctorService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAppointments();
  }


  public get service(): DoctorService {
    return this.doctorService;
  }


  getAppointments() {
    const doctorId = localStorage.getItem("STAFFID");
    this.doctorService.getAppointments(doctorId!);
  }

  onClickView(appointment: Appointment) {
    sessionStorage.setItem('appointmentId', appointment.id.toString());
    console.log(appointment);
    this.router.navigate(["doctor/patient"]);
  }

  onClickDone(appointment: Appointment) {
    appointment.is_done = true;
    this.doctorService.updateAppointment(appointment).subscribe({
      next: (response) => {
        this.toastr.success("Done.");
        this.getAppointments();
      },
    });
  }

}
