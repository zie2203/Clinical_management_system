import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { Validator } from '@angular/forms';
import { dosageValidator, numberOfDaysValidator, quantityValidator } from 'src/app/shared/cms-validators';

@Component({
  selector: 'app-patient-medicine',
  templateUrl: './patient-medicine.component.html',
  styleUrls: ['./patient-medicine.component.scss']
})
export class PatientMedicineComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private doctorService: DoctorService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.getMedicinePrescription();
    this.myForm = this.fb.group({
      medicine: ["", [Validators.required]],
      dosage: ["", [Validators.required, dosageValidator()]],
      quantity: ["", [Validators.required, quantityValidator()]],
      no_of_days: ["", [Validators.required, numberOfDaysValidator()]],
    });
  }

  get service(): DoctorService {
    return this.doctorService;
  }

  get medicine() {
    return this.myForm.get("medicine");
  }

  get dosage() {
    return this.myForm.get("dosage");
  }

  get quantity(){
    return this.myForm.get("quantity");
  }

  get no_of_days() {
    return this.myForm.get("no_of_days");
  }

  onSubmit(): void {
    console.log(this.myForm.value);
    if (this.myForm.valid) {
      this.doctorService.createMedicinePrescription(this.myForm.value)
        .subscribe({
          next: (response) => {
            this.service.getMedicinePrescription();
            this.toastr.success("Added Successfully");
            this.myForm.reset();
          },
          error: (error) => {
            console.log(error);
            this.toastr.error("Invalid Details");
          }
        });
    }
  }
}
