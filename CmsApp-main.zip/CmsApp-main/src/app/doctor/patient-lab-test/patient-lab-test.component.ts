import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Validator } from '@angular/forms';
import { DoctorService } from 'src/app/shared/services/doctor.service';

@Component({
  selector: 'app-patient-lab-test',
  templateUrl: './patient-lab-test.component.html',
  styleUrls: ['./patient-lab-test.component.scss']
})
export class PatientLabTestComponent implements OnInit {

  showReport: string = "";
  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private doctorService: DoctorService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.getLabTest();
    this.service.getLabTestReports();
    this.myForm = this.fb.group({
      test_type: ["", [Validators.required]],
    });
  }

  get service(): DoctorService {
    return this.doctorService;
  }

  get test_type() {
    return this.myForm.get("test_type");
  }

  show(report: string) {
    this.showReport = report;
    return this.showReport;
  }

  onSubmit(): void {
    console.log(this.myForm.value);
    this.doctorService.createLabTest(this.myForm.value)
      .subscribe({
        next: (response) => {
          this.service.getLabTestReports();
          this.toastr.success("Added Successfully");
          this.myForm.reset();
        },
        error: (error) => {
          console.log(error);
          this.toastr.error("Invalid Details");
        }
      });
  }

}
