import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientLabTestComponent } from './patient-lab-test.component';

describe('PatientLabTestComponent', () => {
  let component: PatientLabTestComponent;
  let fixture: ComponentFixture<PatientLabTestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientLabTestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientLabTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
