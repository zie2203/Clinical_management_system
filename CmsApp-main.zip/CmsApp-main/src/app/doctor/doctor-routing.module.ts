import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientAppointmentsComponent } from './patient-appointments/patient-appointments.component';
import { PatientRecordComponent } from './patient-record/patient-record.component';

const routes: Routes = [
  {
    path: "",
    component: PatientAppointmentsComponent
  },
  {
    path: "appointments",
    component: PatientAppointmentsComponent
  },
  {
    path: "patient",
    component: PatientRecordComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctorRoutingModule { }
