import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Validators } from '@angular/forms';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { bloodPressureValidator, sugarLevelValidator, temperatureValidator, weightValidator } from 'src/app/shared/cms-validators';

@Component({
  selector: 'app-patient-diagnosis',
  templateUrl: './patient-diagnosis.component.html',
  styleUrls: ['./patient-diagnosis.component.scss']
})
export class PatientDiagnosisComponent implements OnInit {

  myForm!: FormGroup;

  constructor(private fb: FormBuilder, private doctorService: DoctorService, private toastr: ToastrService) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      weight: ["", [Validators.required, weightValidator()]],
      blood_pressure: ["", [Validators.required, bloodPressureValidator()]],
      sugar_level: ["", [Validators.required, sugarLevelValidator()]],
      temperature: ["", [Validators.required, temperatureValidator()]],
      diagnosis: ["", [Validators.required]],
      note: ["", [Validators.required]],
    });
  }

  get weight() {
    return this.myForm.get("weight");
  }

  get blood_pressure() {
    return this.myForm.get("blood_pressure");
  }

  get sugar_level() {
    return this.myForm.get("sugar_level");
  }

  get temperature() {
    return this.myForm.get("temperature");
  }

  get diagnosis() {
    return this.myForm.get("diagnosis");
  }

  get note() {
    return this.myForm.get("note");
  }


  onSubmit(): void {
    if(this.myForm.valid){
      this.doctorService.createPatientHealth(this.myForm.value)
      .subscribe({
        next: (response) => {
          this.toastr.success("Added Successfully");
        },
        error: (error) => {
          console.log(error);
          this.toastr.error("Invalid Details");
        }
      });
    }
  }

}
