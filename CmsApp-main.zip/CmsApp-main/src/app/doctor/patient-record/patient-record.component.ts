import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { DoctorService } from 'src/app/shared/services/doctor.service';

@Component({
  selector: 'app-patient-record',
  templateUrl: './patient-record.component.html',
  styleUrls: ['./patient-record.component.scss']
})
export class PatientRecordComponent implements OnInit {
  tabComponent: string = "diagnosis";

  constructor(private doctorService: DoctorService) { }

  ngOnInit(): void {
    const appointmentId = sessionStorage.getItem('appointmentId');
    if (appointmentId) {
      this.service.getAppointment(appointmentId);
    }
    this.doctorService.getMedicine();
  }

  public get service(): DoctorService {
    return this.doctorService;
  }

  getImageUrl(imagePath: String): string {
    return environment.apiUrl + imagePath;
  }

  onTabClick(tab: string) {
    this.tabComponent = tab;
  }

}
