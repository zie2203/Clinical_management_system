import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MedicinceAddComponent } from './medicince-add/medicince-add.component';
 import { MedicinceListComponent } from './medicince-list/medicince-list.component';
import { MedicinceEditComponent } from './medicince-edit/medicince-edit.component';
import { HomedashboardComponent } from './homedashboard/homedashboard.component';
import { PrescribtionListComponent } from './prescribtion-list/prescribtion-list.component';

const routes: Routes = [
  {path:'add',component:MedicinceAddComponent},
  {path:'list',component:MedicinceListComponent},
  {path:'edit/',component:MedicinceEditComponent},
  {path:'edit/:id',component:MedicinceEditComponent},
  {path:'dashboard',component:HomedashboardComponent},
  {path:'prescri/list',component:PrescribtionListComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PharmacistRoutingModule { }
