import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PharmacistRoutingModule } from './pharmacist-routing.module';
import { PharmacistComponent } from './pharmacist.component';
 import { FormsModule, ReactiveFormsModule } from '@angular/forms';
 import {NgxPrintModule} from 'ngx-print';
import { MedicinceListComponent } from './medicince-list/medicince-list.component';
import { MedicinceAddComponent } from './medicince-add/medicince-add.component';
import { MedicinceEditComponent } from './medicince-edit/medicince-edit.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { HomedashboardComponent } from './homedashboard/homedashboard.component';
import { PrescribtionListComponent } from './prescribtion-list/prescribtion-list.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    PharmacistComponent,
    MedicinceListComponent,
    MedicinceAddComponent,
    MedicinceEditComponent,
    HomedashboardComponent,
    PrescribtionListComponent
  ],
  imports: [
    CommonModule,
    PharmacistRoutingModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    NgxPrintModule
  ]
})
export class PharmacistModule { }
