import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pharmacist',
  templateUrl: './pharmacist.component.html',
  styleUrls: ['./pharmacist.component.scss']
})
export class PharmacistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
