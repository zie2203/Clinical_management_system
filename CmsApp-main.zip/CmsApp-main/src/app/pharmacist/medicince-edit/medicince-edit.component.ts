import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MedicineState } from 'src/app/shared/models/medicine-state';
import { ToastrService } from 'ngx-toastr';
import { PharmacistService } from 'src/app/shared/services/pharmacist.service';

@Component({
  selector: 'app-medicince-edit',
  templateUrl: './medicince-edit.component.html',
  styleUrls: ['./medicince-edit.component.scss']
})
export class MedicinceEditComponent implements OnInit {

  constructor(public pharmacistService:PharmacistService,public router:Router,public toastr:ToastrService) { }

  ngOnInit(): void {
    this.getMediState();
  }
  getMediState(){
    this.pharmacistService.getMedistate();
  }
// submit form
onsubmit(form:NgForm){
  console.log(form.value);
  //update
  this.editmedicince(form)
  this.router.navigate(['/pharmacist/list'])

}
editmedicince(form:NgForm){
  console.log("editing......")
  this.pharmacistService.updateMedicince(form.value)
  .subscribe((result)=>{
    console.log (result);
    this.toastr.success("updated sucess!!")
     
  })
}
}

