import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicinceEditComponent } from './medicince-edit.component';

describe('MedicinceEditComponent', () => {
  let component: MedicinceEditComponent;
  let fixture: ComponentFixture<MedicinceEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicinceEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MedicinceEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
