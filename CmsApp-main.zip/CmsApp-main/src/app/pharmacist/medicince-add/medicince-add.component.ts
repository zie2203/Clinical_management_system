import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastRef, ToastrService } from 'ngx-toastr';
import { MedicineState } from 'src/app/shared/models/medicine-state';
import {PharmacistService } from 'src/app/shared/services/pharmacist.service';

@Component({
  selector: 'app-medicince-add',
  templateUrl: './medicince-add.component.html',
  styleUrls: ['./medicince-add.component.scss']
})
export class MedicinceAddComponent implements OnInit {


  constructor(public pharmacistService:PharmacistService,public router:Router,private toaster:ToastrService) { }

  ngOnInit(): void {
    this.pharmacistService.getMedistate();
  }
  

  onSubmit(form:NgForm){
    console.log(form.value);
    this.addmedicince(form)
  }
  addmedicince(form:NgForm){
    console.log("inserting...")
    this.pharmacistService.insertPosts(form.value).subscribe(
      (result=>{
        console.log(result);
        this.restForm(form);
        this.toaster.success('submitted successfully')
        this.router.navigate(['/pharmacist/list'])

        
      })
    )
  }
  restForm(form:NgForm){
    if(form!=null){
      form.resetForm();
    }
  }


}