import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicinceAddComponent } from './medicince-add.component';

describe('MedicinceAddComponent', () => {
  let component: MedicinceAddComponent;
  let fixture: ComponentFixture<MedicinceAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicinceAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MedicinceAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
