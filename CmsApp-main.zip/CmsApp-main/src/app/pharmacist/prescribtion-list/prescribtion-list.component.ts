import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { flatMap } from 'rxjs';
import { PharmacistService } from 'src/app/shared/services/pharmacist.service';

@Component({
  selector: 'app-prescribtion-list',
  templateUrl: './prescribtion-list.component.html',
  styleUrls: ['./prescribtion-list.component.scss']
})
export class PrescribtionListComponent implements OnInit {

  appointmentForm!: FormGroup;
  generateBill: boolean = false;

  constructor(private formBuilder: FormBuilder, public pharmacistService: PharmacistService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.appointmentForm = this.formBuilder.group({
      appointmentId: "",
    });
  }

  calculateTotal(): number {
    let total = 0;
    for (let prescription of this.pharmacistService.medicinePrescriptions) {
      total += prescription.medicine.rate * prescription.quantity;
    }
    return total;
  }

  calculateGst() {
    const gst = this.calculateTotal() * 0.18;
    return gst;
  }

  onSubmit() {
    console.log(this.appointmentForm.value);
    this.pharmacistService.getMedicinePrescription(this.appointmentForm.value.appointmentId);
  }

  submitBill() {
    this.pharmacistService.saveMedicineBill().subscribe({
      next: (response) => {
        this.generateBill = true;
        this.toastr.success("Successfully Saved");
      },
      error: (error) => {
        this.toastr.error("Invalid Prescription");
      },
    });
  }

}
