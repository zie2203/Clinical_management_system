import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrescribtionListComponent } from './prescribtion-list.component';

describe('PrescribtionListComponent', () => {
  let component: PrescribtionListComponent;
  let fixture: ComponentFixture<PrescribtionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrescribtionListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrescribtionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
