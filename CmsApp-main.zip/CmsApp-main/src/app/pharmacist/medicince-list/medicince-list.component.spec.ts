import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicinceListComponent } from './medicince-list.component';

describe('MedicinceListComponent', () => {
  let component: MedicinceListComponent;
  let fixture: ComponentFixture<MedicinceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicinceListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MedicinceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
