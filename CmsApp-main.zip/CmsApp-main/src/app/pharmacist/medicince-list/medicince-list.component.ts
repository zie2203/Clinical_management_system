import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Medicine } from 'src/app/shared/models/medicine';
import { PharmacistService } from 'src/app/shared/services/pharmacist.service';

@Component({
  selector: 'app-medicince-list',
  templateUrl: './medicince-list.component.html',
  styleUrls: ['./medicince-list.component.scss']
})
export class MedicinceListComponent implements OnInit {
  searchTerm='';
  // p:number=1


  constructor(public Pharmacistservice:PharmacistService,public router:Router) { }

  ngOnInit(): void {
    this.Pharmacistservice.bindListPosts()
  }
  // updating the medicince
  updateMedicince(p:Medicine){
    console.log(p);
    this.populatePostsData(p);
    // from one page to another use router
    this.router.navigate(['pharmacist/edit/',p.id])
  }
  populatePostsData(p:Medicine){
    this.Pharmacistservice.FormPostsData=Object.assign({},p)
  }

}
