import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-patient-edit',
  templateUrl: './patient-edit.component.html',
  styleUrls: ['./patient-edit.component.scss']
})
export class PatientEditComponent implements OnInit {

  constructor(public patientsService: PatientsService, public router :Router,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.patientsService.listbloodgroup();
  }
  onSubmit(form :NgForm)
  {
    console.log(form.value);// to see the contents from form
    //update
    this.editPatients(form);
  }
  editPatients(form: NgForm) {
    console.log("editing...")
    form.value.bloodGroup = { id: form.value.bloodGroup };
    this.patientsService.updatePatient(form.value).subscribe((result)=>{console.log(result);this.router.navigate(['receptionist/list_patients'])})
    this.toastr.success('Patient updated successfully!');

  }
}
