import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Appointment } from 'src/app/shared/models/appointment';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html',
  styleUrls: ['./appointment-list.component.scss']
})
export class AppointmentListComponent implements OnInit {
  searchTerm = "";
  appointment = 0;
  constructor(public patientService: PatientsService, public router: Router) { }

  ngOnInit(): void {
    this.patientService.bindListAppointments()
  }
  generate_bill(appointment:Appointment)
  {
    console.log(appointment);
    this.populatePostsData(appointment);
    this.router.navigate(['receptionist/appointments_bill' , appointment.id]);

    //localhost : 4200/posts/edit/id 
  }
  populatePostsData(p :Appointment)
  {
    this.patientService.bill = Object.assign({},p)

  }
  updateAppointments(p:Appointment)
  {
    console.log(p);
    this.populateApmtsData(p);
    this.router.navigate(['/receptionist/edit_appointments' , p.id]);

    //localhost : 4200/posts/edit/id 
  }
  populateApmtsData(p :Appointment)
  {
    this.patientService.formAppointmentsData = Object.assign({},p)

  }
}
