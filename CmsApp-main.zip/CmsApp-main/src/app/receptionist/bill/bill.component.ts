import { Component, OnInit } from '@angular/core';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.scss']
})
export class BillComponent implements OnInit {

  constructor(public patientsService: PatientsService) { }

  ngOnInit(): void {
    this.patientsService.bindListAppointments
  }
}
