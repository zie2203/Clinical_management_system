import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientAddComponent } from './patient-add/patient-add.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { PatientEditComponent } from './patient-edit/patient-edit.component';
import { AppointmentListComponent } from './appointment-list/appointment-list.component';
import { AppointmentAddComponent } from './appointment-add/appointment-add.component';
import { HomeComponent } from './home/home.component';
import { BillComponent } from './bill/bill.component';
import { DoctorComponent } from '../doctor/doctor.component'; 
import { DocListComponent } from './doc-list/doc-list.component';
import { AppointmentEditComponent } from './appointment-edit/appointment-edit.component';

const routes: Routes = 
[
{path:"add_patients",component:PatientAddComponent},
{path:"list_patients",component:PatientListComponent},
{path:"list_patients/:id",component:PatientListComponent},
{path:"edit_patients",component:PatientEditComponent},
{path:"edit_patients/:id",component:PatientEditComponent},
{path:"list_appointments",component:AppointmentListComponent},
{path:"add_appointments",component:AppointmentAddComponent},
{path:"",component:HomeComponent},
{path:"appointments_bill/:id",component:BillComponent},
{path:"doc_list",component:DocListComponent},
{path:"edit_appointments",component:AppointmentEditComponent},
{path:"edit_appointments/:id",component:AppointmentEditComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReceptionistRoutingModule { }
