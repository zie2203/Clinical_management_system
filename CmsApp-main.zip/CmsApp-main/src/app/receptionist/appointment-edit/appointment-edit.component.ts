import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-appointment-edit',
  templateUrl: './appointment-edit.component.html',
  styleUrls: ['./appointment-edit.component.scss']
})
export class AppointmentEditComponent implements OnInit {

  constructor(public patientsService: PatientsService, public router :Router,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.patientsService.listDept();
    this.patientsService.getDoctor();
    this.patientsService.getDoctorsBySpecialization;
    this.patientsService.getPatient();
  }
  onSubmit(form :NgForm)
  {
    console.log(form.value);// to see the contents from form
    //update
    this.editAppointments(form);
  }
  editAppointments(form: NgForm) {
    console.log("editing...")
    this.patientsService.updateAppointments(form.value).subscribe((result)=>{console.log(result);this.router.navigate(['receptionist/list_appointments'])})
    this.toastr.success('Appointment updated successfully!');

  }
}
