import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-patient-add',
  templateUrl: './patient-add.component.html',
  styleUrls: ['./patient-add.component.scss']
})
export class PatientAddComponent implements OnInit {

  constructor(public  patientsService: PatientsService , public router:Router ,private toastr: ToastrService) { }

  ngOnInit(): void {
       this.patientsService.listbloodgroup();

  }
  addMethod()
  {
    //call the service method
  
  }
  onSubmit(form :NgForm)
  {
    console.log(form.value);// to see the contents from form
    //insert
    this.addPatients(form);
  
  }
  addPatients(form:NgForm)
  {
    console.log("Inserting...")
    form.value.bloodGroup = { id: form.value.bloodGroup };
    this.patientsService.insertPatients(form.value).subscribe(
      (result=>
      {
        console.log(result);
        this.resetForm(form);//reset the form
        this.toastr.success('New patient inserted successfully!');
        this.router.navigate(['receptionist/list_patients'])
      })
      )
  }
  //reset form after add records
  resetForm(form:NgForm)
  {
    if (form != null)
    {
      form.resetForm();
    }
  }
}
