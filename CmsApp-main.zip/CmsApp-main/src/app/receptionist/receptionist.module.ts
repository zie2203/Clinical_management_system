import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReceptionistRoutingModule } from './receptionist-routing.module';
import { ReceptionistComponent } from '../receptionist/receptionist.component';
import { PatientAddComponent } from './patient-add/patient-add.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { PatientEditComponent } from './patient-edit/patient-edit.component';
import { FormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import { AppointmentListComponent } from './appointment-list/appointment-list.component';
import { AppointmentAddComponent } from './appointment-add/appointment-add.component';
import { HomeComponent } from './home/home.component';
import { BillComponent } from './bill/bill.component';
import { DocListComponent } from './doc-list/doc-list.component';
import { AppointmentEditComponent } from './appointment-edit/appointment-edit.component';
import { FooterComponent } from '../shared/footer/footer.component';
import { HeaderComponent } from '../shared/header/header.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    ReceptionistComponent,
    PatientAddComponent,
    PatientListComponent,
    PatientEditComponent,
    AppointmentListComponent,
    AppointmentAddComponent,
    HomeComponent,
    BillComponent,
    DocListComponent,
    AppointmentEditComponent,
  ],
  imports: [
    CommonModule,
    ReceptionistRoutingModule,
    FormsModule ,
    Ng2SearchPipeModule ,
    NgxPaginationModule,
    SharedModule
  ]
})
export class ReceptionistModule { }
