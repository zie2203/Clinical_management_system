import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientsService } from 'src/app/shared/services/patients.service';
import { Staff } from 'src/app/shared/models/staff';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(public patientsService:PatientsService, public router:Router) { }

  ngOnInit(): void {
    this.patientsService.getStaff();
  }
  isReceptionist(): Staff[] {
    // Assuming the role name is case-sensitive
    return this.patientsService.staff.filter(staff => staff.role.name === 'Receptionist');
  }
}
