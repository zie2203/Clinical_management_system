import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { forkJoin } from 'rxjs';
import { Appointment } from 'src/app/shared/models/appointment';
import { Doctor } from 'src/app/shared/models/doctor';
import { Specialization } from 'src/app/shared/models/specialization';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-appointment-add',
  templateUrl: './appointment-add.component.html',
  styleUrls: ['./appointment-add.component.scss']
})
export class AppointmentAddComponent implements OnInit {
 
  searchTerm = ""
  constructor(public  patientsService: PatientsService , public router:Router ,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.patientsService.listDept();
    this.patientsService.getDoctor();
    this.patientsService.getDoctorsBySpecialization;
    this.patientsService.getPatient();
    this.patientsService.bindListDoc()
    console.log('Doctor Data:', this.patientsService.doctor);
  }

  
  addMethod()
  {
    //call the service method
  
  }
  addAppointments()
  {
    console.log("Inserting...")
    const appoint = this.patientsService.formBookAppointmentData;
    this.patientsService.insertAppointment(appoint).subscribe(
      (result =>
      {
        console.log(result);
        this.toastr.success('Appointment Id: ' + result.id + ' for ' + result.patient.first_name + ' inserted successfully!');
        this.router.navigate(['receptionist/list_appointments'])
      })
      )
  }
  //reset form after add records
  resetForm(form:NgForm)
  {
    if (form != null)
    {
      form.resetForm();
    }
  }
  bookDoc(doctor: Doctor): void {
    this.patientsService.formBookAppointmentData.doctor = doctor;
  }
}

