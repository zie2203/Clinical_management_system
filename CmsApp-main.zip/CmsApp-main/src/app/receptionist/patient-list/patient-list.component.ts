import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Patient } from 'src/app/shared/models/patient';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.scss']
})
export class PatientListComponent implements OnInit {
  p:number = 1;
  searchTerm ="";
  constructor(public patientService: PatientsService,public router :Router,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.patientService.bindListPatients()
  }
  updatePatients(p:Patient)
  {
    console.log(p);
    this.populatePostsData(p);
    this.router.navigate(['receptionist/edit_patients' , p.id]);

    //localhost : 4200/posts/edit/id 
  }
  populatePostsData(p :Patient)
  {
    this.patientService.formPatientsData = Object.assign({},p)

  }
  deletePatients(_id:number)
  {
    if(confirm
    ("Are you sure to delete this record?"))
    {
      //call service method for delete
      this.patientService.deletePatients(_id).subscribe((response)=>{console.log(response);this.patientService.bindListPatients();},
      (error)=>{console.log(error);})
      this.toastr.success('Patient deleted successfully!');


    }
  }
  bookAppointments(p : Patient)
  {
    console.log(p);
    this.populateAppointmentsData(p);
    this.router.navigate(['receptionist/add_appointments'])
  }
  populateAppointmentsData(p:Patient )
  {
    this.patientService.formBookAppointmentData.patient = Object.assign({},p)
  }
}
