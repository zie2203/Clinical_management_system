import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientsService } from 'src/app/shared/services/patients.service';

@Component({
  selector: 'app-doc-list',
  templateUrl: './doc-list.component.html',
  styleUrls: ['./doc-list.component.scss']
})
export class DocListComponent implements OnInit {
  searchTerm="";
  constructor(public DoctorService:PatientsService, public router:Router) { }

  ngOnInit(): void {
    this.DoctorService.bindListDoc()
    console.log('Doctor Data:', this.DoctorService.doctor);
  }

}
