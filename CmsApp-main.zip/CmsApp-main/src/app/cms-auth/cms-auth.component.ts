import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-auth',
  templateUrl: './cms-auth.component.html',
  styleUrls: ['./cms-auth.component.scss']
})
export class CmsAuthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
