import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmsAuthRoutingModule } from './cms-auth-routing.module';
import { CmsAuthComponent } from './cms-auth.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SignupComponent } from './signup/signup.component';


@NgModule({
  declarations: [
    CmsAuthComponent,
    LoginComponent,
    SignupComponent,
  ],
  imports: [
    CommonModule,
    CmsAuthRoutingModule,
    ReactiveFormsModule
  ]
})
export class CmsAuthModule { }
