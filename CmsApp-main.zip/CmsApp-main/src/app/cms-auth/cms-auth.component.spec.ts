import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmsAuthComponent } from './cms-auth.component';

describe('CmsAuthComponent', () => {
  let component: CmsAuthComponent;
  let fixture: ComponentFixture<CmsAuthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CmsAuthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmsAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
