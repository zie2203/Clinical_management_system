import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CmsAuthService } from 'src/app/shared/services/cms-auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: CmsAuthService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ["", [Validators.required]],
      password: ["", [Validators.required]],
    });

    const role = this.authService.alreadyLogged();
    if(role){
      this.handleLoginNavigation(role);
    }
  }

  get formControls() {
    return this.loginForm.controls;
  }


  login() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value)
        .subscribe({
          next: (response) => {
            this.authService.setStorage(response);
            this.toastr.success("Login Successful");
            this.handleLoginNavigation(response.staff.role.name);
          },
          error: (error) => {
            console.log("Login error: ", error);
            this.toastr.error("Invalid Login details");
          },
        });
    }
  }

  handleLoginNavigation(role: string){
    switch (role) {
      case "Admin": {
        this.router.navigate(["admin"]);
        break;
      }
      case "Doctor": {
        this.router.navigate(["doctor"]);
        break;
      }
      case "Lab Technician": {
        this.router.navigate(["labtechnician/home"]);
        break;
      }
      case "Pharmacist": {
        this.router.navigate(["pharmacist/dashboard"]);
        break;
      }
      case "Receptionist": {
        this.router.navigate(["receptionist"]);
        break;
      }
    }
  }

}
